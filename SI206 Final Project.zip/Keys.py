#YelpAPI
client_ID = "JGmZos5EmGBoY_vkbvTGw"
API_Key = "ob0tETqlKnY-p2pgkkhFaVcH7wSXOcw0FsPHm_rmbLL_HnDMQO7xR-9ddJX8ZRnwpiJjaz-AQgRbXffR8RBzVkg5yBcYivumrCrc0HxwFqbXM8gdBH3vfcrb6--kXHYx"

#ZomatoAPI
ZomatoAPI = "92f52707cb7d5d28d57b18760216faf5"

#OpenWeatherMap
api_key = "18986dda768120a40dedd844f76d161a"



